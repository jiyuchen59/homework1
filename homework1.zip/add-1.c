#include <stdio.h>

int add(int a)
{
	int b = a + 3;
	return b;
}
